// Função para rolar suavemente até a seção ao clicar no link do menu
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const targetId = this.getAttribute('href');
        const targetElement = document.querySelector(targetId);

        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 70, // Ajusta para a altura do header fixo
                behavior: 'smooth'
            });
        }
    });
});

// Adicionar classe 'scrolled' ao body quando o usuário rolar a página
window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
        document.body.classList.add('scrolled');
    } else {
        document.body.classList.remove('scrolled');
    }
});

// Inicializar o LightWidget do Instagram após o carregamento completo da página
document.addEventListener('DOMContentLoaded', function() {
    // Verifica se o elemento do Instagram existe
    const instagramWidget = document.querySelector('.lightwidget-widget');
    if (instagramWidget) {
        // O LightWidget já é carregado via script no HTML, então não precisa de inicialização adicional aqui
        // Mas podemos adicionar um fallback ou tratamento de erro se necessário
        console.log('Instagram widget carregado');
    }
});

// Adicionar animação aos cards dos procedimentos ao rolar a página
document.addEventListener('DOMContentLoaded', function() {
    const observerOptions = {
        root: null,
        rootMargin: '0px',
        threshold: 0.1
    };

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animated');
                observer.unobserve(entry.target); // Para animar apenas uma vez
            }
        });
    }, observerOptions);

    // Observa todos os cards de procedimentos
    document.querySelectorAll('.card').forEach(card => {
        observer.observe(card);
    });
});
